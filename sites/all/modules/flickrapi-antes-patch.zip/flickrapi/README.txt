The Flickr API module serves as a helper module for other Drupal Flickr modules.
You don't need this module unless another module requires it or you want to
develop a new Flickr-based module.

To use this module, or any Flickr services modules, you will need to obtain an
API key from http://www.flickr.com/services/api
